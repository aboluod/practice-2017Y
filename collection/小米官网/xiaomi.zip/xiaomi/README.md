# xiaomi
仿小米官网

[演示地址](http://iwuly.com/xiaomi)
